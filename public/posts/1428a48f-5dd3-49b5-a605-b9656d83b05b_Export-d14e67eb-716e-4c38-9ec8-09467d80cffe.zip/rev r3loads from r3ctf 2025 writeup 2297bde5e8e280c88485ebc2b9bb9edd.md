# rev/r3loads from r3ctf 2025 writeup

```
points: 929 pts
solves: 11 solves
```

## Initial analysis

this is an autorev chall, we are given 11423 executables each one is in it’s directory along with a set of shared libraries, the readme says that each binary takes 8 bytes input and final output of the chall will be a jpg which is the concatenation of 11423 right inputs.

each part is like this:

```bash
player@notarch:~/ctfs/r3/r3loads/game/300$ ls
beatme                               RRRRRRRRRRRR3R33RRRR3R3R3R3RRR33.so  RRRRRRRRRRRR3R33RRRRRRRRRRR33333.so  RRRRRRRRRRRR3R3R33333RR3R33333RR.so
RRRRRRRRRRRR3R33RRR3R3RRRR333RRR.so  RRRRRRRRRRRR3R33RRRR3R3R3R3RRRR3.so  RRRRRRRRRRRR3R33RRRRRRRRRRR333R3.so  RRRRRRRRRRRR3R3R33333RR3R3333R3R.so
RRRRRRRRRRRR3R33RRR3R3RRRR33R33R.so  RRRRRRRRRRRR3R33RRRRR33R3R33333R.so  RRRRRRRRRRRR3R33RRRRRRRRRRR33R33.so  RRRRRRRRRRRR3R3R33333RR3R3333RRR.so
RRRRRRRRRRRR3R33RRR3R3RRRR33R3RR.so  RRRRRRRRRRRR3R33RRRRR33R3R3333RR.so  RRRRRRRRRRRR3R33RRRRRRRRRRR33RR3.so  RRRRRRRRRRRR3R3R33333RR3R333R33R.so
RRRRRRRRRRRR3R33RRRR33333R33RRR3.so  RRRRRRRRRRRR3R33RRRRR33R3R333R3R.so  RRRRRRRRRRRR3R33RRRRRRRRRRR3R333.so  RRRRRRRRRRRR3R3R3333R3R33RRR333R.so
RRRRRRRRRRRR3R33RRRR33333R3R3333.so  RRRRRRRRRRRR3R33RRRRR33R3R333RRR.so  RRRRRRRRRRRR3R33RRRRRRRRRRR3R3R3.so  RRRRRRRRRRRR3R3R3333R3R33RRR33RR.so
RRRRRRRRRRRR3R33RRRR33333R3R33R3.so  RRRRRRRRRRRR3R33RRRRR33R3R33R33R.so  RRRRRRRRRRRR3R3R3333333RRR33RRR3.so  RRRRRRRRRRRR3R3R3333R3R33RRR3R3R.so
RRRRRRRRRRRR3R33RRRR33333R3R3R33.so  RRRRRRRRRRRR3R33RRRRR33R3R33R3RR.so  RRRRRRRRRRRR3R3R3333333RRR3R3333.so  RRRRRRRRRRRR3R3R3333R3R33RRR3RRR.so
RRRRRRRRRRRR3R33RRRR33333R3R3RR3.so  RRRRRRRRRRRR3R33RRRRRR333333R333.so  RRRRRRRRRRRR3R3R3333333RRR3R33R3.so  RRRRRRRRRRRR3R3R3333R3R33RRRR33R.so
RRRRRRRRRRRR3R33RRRR3R3R3R3RR3R3.so  RRRRRRRRRRRR3R33RRRRRR333333R3R3.so  RRRRRRRRRRRR3R3R3333333RRR3R3R33.so  RRRRRRRRRRRR3R3R3333RR3RR33RRRRR.so 
```

running it gives us:

```bash
player@notarch:~/ctfs/r3/r3loads/game/300$ ./beatme
Weclome to r3ctf 2025, can you beat me? 300/11423
Input something: 
aaaabbbb
Try again!
```

we will first starting by reversing a binary, then see what we can automate and script it.

## the “rev” part:

loading one executable in ida we get this (variable declarations removed for clarity): 

```c
__int64 __fastcall main(int a1, char **a2, char **a3)
{
  v92 = __readfsqword(0x28u);
  
  // part 1
  handle = dlopen("./RRRRRRRRRRRRRRRRRRRR3RR33R3333RR.so", 1);
  if ( !handle )
    exit(1);
  dlerror();
  qword_7038 = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD))dlsym(handle, "RRRRRRRRRRRRRRRRRRRR3RR33R3333R3");
  if ( dlerror() )
    exit(2);
  handlea = dlopen("./RRRRRRRRRRRRRRRRRRR3RR3RR333RR33.so", 1);
  if ( !handlea )
    exit(1);
  dlerror();
  qword_7028 = (__int64)dlsym(handlea, "RRRRRRRRRRRRRRRRRRR3RR3RR333R3RR");
  if ( dlerror() )
    exit(2);
  handleb = dlopen("./RRRRRRRRRRRRRRRRRRRR33333RRRRR33.so", 1);
  if ( !handleb )
    exit(1);
  dlerror();
  qword_7060 = (__int64)dlsym(handleb, "RRRRRRRRRRRRRRRRRRRR33333RRRR3RR");
  if ( dlerror() )
    exit(2);
  handlec = dlopen("./RRRRRRRRRRRRRRRRRRRRRRRR3333R333.so", 1);
  if ( !handlec )
    exit(1);
  dlerror();
  qword_7058 = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD))dlsym(handlec, "RRRRRRRRRRRRRRRRRRRRRRRR3R3333R3");
  if ( dlerror() )
    exit(2);
  handled = dlopen("./RRRRRRRRRRRRRRRRRRRRR333RR33R3R3.so", 1);
  if ( !handled )
    exit(1);
  dlerror();
  qword_7030 = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD))dlsym(handled, "RRRRRRRRRRRRRRRRRRRRR333RR33R33R");
  if ( dlerror() )
    exit(2);
  handlee = dlopen("./RRRRRRRRRRRRRRRRRRR33RRR33R3RRRR.so", 1);
  if ( !handlee )
    exit(1);
  dlerror();
  unk_7048 = dlsym(handlee, "RRRRRRRRRRRRRRRRRRR33RRR33R3RRR3");
  if ( dlerror() )
    exit(2);
  handlef = dlopen("./RRRRRRRRRRRRRRRRRRRRRRR333RR3RR3.so", 1);
  if ( !handlef )
    exit(1);
  dlerror();
  qword_7018 = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD))dlsym(handlef, "RRRRRRRRRRRRRRRRRRRRRRR333RR3R3R");
  if ( dlerror() )
    exit(2);
  handleg = dlopen("./RRRRRRRRRRRRRRRRRRR3R3R3R33333R3.so", 1);
  if ( !handleg )
    exit(1);
  dlerror();
  qword_7050 = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD))dlsym(handleg, "RRRRRRRRRRRRRRRRRRR3R3R3R333333R");
  if ( dlerror() )
    exit(2);
  handleh = dlopen("./RRRRRRRRRRRRRRRRRRRRR3RR333333R3.so", 1);
  if ( !handleh )
    exit(1);
  dlerror();
  qword_7020 = (__int64)dlsym(handleh, "RRRRRRRRRRRRRRRRRRRRR3RR33RRRRRR");
  if ( dlerror() )
    exit(2);
  handlei = dlopen("./RRRRRRRRRRRRRRRRRRRR33R33R3RRR33.so", 1);
  if ( !handlei )
    exit(1);
  dlerror();
  qword_7040 = (__int64 (__fastcall *)(_QWORD, _QWORD, _QWORD))dlsym(handlei, "RRRRRRRRRRRRRRRRRRRR33R33R3RR3RR");
  if ( dlerror() )
    exit(2);
   // part 2
  v78 = qword_7050;
  v74 = qword_7018(2519191252LL, 4076126875LL, 1218786772LL);
  v70 = qword_7030(1609595473LL, 3128484619LL, 4087579104LL);
  v68 = qword_7030;
  v65 = qword_7030(2690426595LL, 3364721587LL, 437895104LL);
  v61 = qword_7038(1283178194LL, 772598900LL, 4044443833LL);
  v56 = qword_7038;
  v53 = qword_7050(3011521025LL, 3896653472LL, 2969271853LL);
  v58 = qword_7050(2597383473LL, 1573495243LL, 1272799309LL);
  v51 = qword_7030;
  v49 = qword_7050(4124176520LL, 2851192274LL, 849819070LL);
  v47 = qword_7030(4204980766LL, 3303036188LL, 1300188808LL);
  v45 = qword_7030;
  v3 = qword_7040(1902249305LL, 480323615LL, 828915229LL);
  v4 = qword_7058(1051978252LL, 1556639948LL, 4057401978LL);
  v5 = qword_7050;
  v6 = qword_7040(1413845339LL, 1773044344LL, 1357571684LL);
  v7 = qword_7030(2424675220LL, 1451130298LL, 2243725890LL);
  v8 = qword_7038(2248010869LL, 4277979131LL, 4162855085LL);
  v9 = v5(v8, v7, v6);
  v10 = v45(v9, v4, v3);
  v11 = v51(v10, v47, v49);
  v12 = v56(v11, v58, v53);
  v13 = v68(v12, v61, v65);
  v91[0] = v78(v13, v70, v74);
  v79 = qword_7050;
  v75 = qword_7038(2252283101LL, 494639012LL, 2637468696LL);
  v71 = qword_7040(792239779LL, 4076212580LL, 2712479238LL);
  v69 = qword_7030;
  v66 = qword_7018(3865308284LL, 3805672778LL, 1080794858LL);
  v62 = qword_7038(1863963938LL, 1702626942LL, 2575324878LL);
  v57 = qword_7038;
  v54 = qword_7038(1357907110LL, 3832200346LL, 455731628LL);
  v59 = qword_7058(3455633054LL, 674668955LL, 3289048719LL);
  v52 = qword_7030;
  v50 = qword_7050(2970750527LL, 1480402215LL, 2703108150LL);
  v48 = qword_7058(2494397303LL, 3030882003LL, 1179715252LL);
  v46 = qword_7058;
  v14 = qword_7040(40620835LL, 3318471360LL, 2207650845LL);
  v15 = qword_7018(1006498893LL, 711788195LL, 1183453435LL);
  v16 = qword_7038;
  v17 = qword_7040(1672732083LL, 401989266LL, 3341448835LL);
  v18 = qword_7040(3541700768LL, 3304837126LL, 3494717532LL);
  v19 = qword_7038(619649146LL, 391288332LL, 3218547244LL);
  v20 = v16(v19, v18, v17);
  v21 = v46(v20, v15, v14);
  v22 = v52(v21, v48, v50);
  v23 = v57(v22, v59, v54);
  v24 = v69(v23, v62, v66);
  v91[3] = v79(v24, v71, v75);
  v25 = qword_7050;
  LODWORD(v79) = qword_7038(3506064512LL, 2110474017LL, 358014856LL);
  v76 = qword_7040(144378091LL, 2672728229LL, 2646192054LL);
  v26 = qword_7038;
  v72 = qword_7038(3765020811LL, 1633762065LL, 3301273113LL);
  LODWORD(v69) = qword_7050(711354758LL, 3844827092LL, 358041699LL);
  v67 = qword_7058;
  v63 = qword_7058(2021850418LL, 2909356192LL, 60369934LL);
  LODWORD(v57) = qword_7040(3929200604LL, 3942956373LL, 263092407LL);
  v55 = qword_7040;
  v60 = qword_7058(553441557LL, 546735616LL, 220887434LL);
  LODWORD(v52) = qword_7050(3064281611LL, 12666219LL, 1813867021LL);
  v27 = qword_7050;
  v28 = qword_7040(4176599994LL, 3799277863LL, 662859156LL);
  v29 = qword_7038(2174400086LL, 1471899898LL, 2172788515LL);
  v30 = qword_7050(2452834230LL, 3738633808LL, 2172492116LL);
  v31 = v27(v30, v29, v28);
  v32 = v55(v31, (unsigned int)v52, v60);
  v33 = v67(v32, (unsigned int)v57, v63);
  v34 = v26(v33, (unsigned int)v69, v72);
  v91[2] = v25(v34, v76, (unsigned int)v79);
  v35 = qword_7038;
  LODWORD(v79) = qword_7038(3376956997LL, 3487120587LL, 1389174544LL);
  v77 = qword_7018(264732934LL, 2848765287LL, 3377213004LL);
  v36 = qword_7050;
  v73 = qword_7038(759482441LL, 2318579817LL, 2362102760LL);
  LODWORD(v69) = qword_7030(570055162LL, 892712945LL, 1882563156LL);
  v37 = qword_7018;
  LODWORD(v67) = qword_7030(1702113315LL, 1339171625LL, 98089672LL);
  v64 = qword_7038(2670283717LL, 1353313077LL, 3169637536LL);
  v38 = qword_7030;
  LODWORD(v57) = qword_7050(4235657283LL, 433066747LL, 1625652836LL);
  v39 = qword_7050(2496388067LL, 258905451LL, 3454969537LL);
  v40 = qword_7038(1662268502LL, 2639566582LL, 1516828359LL);
  v41 = v38(v40, v39, (unsigned int)v57);
  v42 = v37(v41, v64, (unsigned int)v67);
  v43 = v36(v42, (unsigned int)v69, v73);
  v91[1] = v35(v43, v77, (unsigned int)v79);
  // part 3
  puts("Weclome to r3ctf 2025, can you beat me? 1/11423");
  puts("Input something: ");
  buf = 0LL;
  read(0, &buf, 8uLL);
  sub_1630(&buf, v91);
  if ( buf == 0xF06203EC3D2C5B74LL )
    puts("You win!");
  else
    puts("Try again!");
  return 0LL;
}
```

this main function can be separated into 3 parts:

- part 1

the first thing it does is load 10 functions (which will be used later)  from the dynamic libraries in the same directory, it uses dlopen to load the library and dlsym to get the function from it, i will show how i got what one function does:

```c
handlee = dlopen("./RRRRRRRRRRRRRRRRRRR33RRR33R3RRRR.so", 1);
  if ( !handlee )
    exit(1);
  dlerror();
  qword_7048 = dlsym(handlee, "RRRRRRRRRRRRRRRRRRR33RRR33R3RRR3");
```

opening this function in binja we get the following:

![Screenshot from 2025-07-07 18-50-52.png](rev%20r3loads%20from%20r3ctf%202025%20writeup%202297bde5e8e280c88485ebc2b9bb9edd/Screenshot_from_2025-07-07_18-50-52.png)

it loads another function from another library and calls it, while only operating on arg3.

it seems that it keeps doing this a few times until it reaches the last function which defines the operation.

the path (in this case it only does it only does it one time):

![Screenshot from 2025-07-07 18-52-16.png](rev%20r3loads%20from%20r3ctf%202025%20writeup%202297bde5e8e280c88485ebc2b9bb9edd/Screenshot_from_2025-07-07_18-52-16.png)

we can see in the end it returns arg1 - arg2, and also it does not use the third argument, this actually is the case for all the other functions, arg3 is never used, it is likely used as an obfuscation mechanism so we can ignore it.

the functions in order are (note that all arguments and returns are unsigned ints):

```c
xor_first_two => arg1 ^ arg2
read_integer_at_offset => ((unsigned int*)arg1)[arg2]
add_at_arg1_arg2 => *((unsigned int*)arg1) += arg2
and_arg1_arg2 => arg1 & arg2
add_arg1_arg2 => arg1 + arg2
subtract_arg1_arg2 => arg1 - arg2
mult_arg1_arg2 => arg1 * arg2
or_arg1_arg2 => arg1 | arg2
integer_div_arg1_arg2 => arg1 / arg2
bitwise_not => ~arg1
```

after reversing all functions and renaming them we move to the second part.

- part 2

it’s code after renaming the functions is accessible here, the first thing i noticed about this part is that it is all just operations on constants, it seems to be writing four unsigned ints in v91, we can extract it using gdb by setting a breakpoint just before the call to sub_1630, then inspecting the memory at rsi.

- part 3

```c
puts("Weclome to r3ctf 2025, can you beat me? 1/11423");
  puts("Input something: ");
  buf = 0LL;
  read(0, &buf, 8uLL);
  sub_1630((unsigned int *)&buf, v91);
  if ( buf == 0xF06203EC3D2C5B74LL )
    puts("You win!");
  else
    puts("Try again!");
```

this part read 8 bytes, then calls sub_1630 on it with v91 which is constant and likely used as a key to some encryption on buf.

### reversing the encryption function:

here is the encrypt function:

```c
unsigned __int64 __fastcall sub_1630(unsigned int *input, unsigned int *a2)
{
  v187 = __readfsqword(0x28u);
  first = *input;
  second = input[1];
  v168 = 0;
  v185 = 0uLL;
  memset(S, 0, 0x400uLL);
  S[0] = 1;
  S[1] = 2;
  S[2] = 3;
  S[3] = 4;
  S[4] = 5;
  for ( i = 0; i <= 255; ++i )
    S[i] = i;
  v170 = 0;
  v171 = 0;
  for ( i = 0; i <= 255; ++i )
  {
    v184 = S[i];
    v170 = (unsigned __int8)(v184 + v170 + a2[v171]);
    S[i] = S[v170];
    S[v170] = v184;
    if ( (unsigned int)++v171 > 3 )
      v171 = 0;
  }
  do
  {
    v172 = and_arg1_arg2(v168, 3LL, 4267278302LL);
    
    // start of static1
    
    v162 = mult_arg1_arg2;                      
    v159 = and_arg1_arg2;
    v154 = add_arg1_arg2(3879220815LL, 1303544047LL, 1673289997LL);
    v148 = or_arg1_arg2(119385303LL, 3231329148LL, 141954786LL);
    v145 = bitwise_not;
    v137 = and_arg1_arg2(1503872738LL, 978965565LL, 1470160614LL);
    v125 = mult_arg1_arg2(761654413LL, 3043887596LL, 4085454309LL);
    v120 = mult_arg1_arg2;
    v131 = xor_first_two(3333670936LL, 2147831941LL, 2217132274LL);
    v115 = add_arg1_arg2(4141055499LL, 1038626365LL, 1517838417LL);
    v112 = xor_first_two;
    v109 = add_arg1_arg2(2686461105LL, 3867813406LL, 686930351LL);
    v106 = xor_first_two(3259940977LL, 1820144441LL, 2738368048LL);
    v103 = mult_arg1_arg2;
    v2 = bitwise_not(2920661428LL, 408102610LL, 758347707LL);
    v3 = xor_first_two(2688446990LL, 3924691225LL, 3780184521LL);
    v4 = or_arg1_arg2;
    v5 = xor_first_two(715168552LL, 4203380807LL, 4042894304LL);
    v6 = and_arg1_arg2(3362982059LL, 1951226027LL, 2091265364LL);
    v7 = mult_arg1_arg2(2447727191LL, 4231433857LL, 2356928693LL);
    v8 = v4(v7, v6, v5);
    v9 = v103(v8, v3, v2);
    v10 = v112(v9, v106, v109);
    v11 = v120(v10, v115, v131);
    v12 = v145(v11, v125, v137);
    LODWORD(v159) = v159(v12, v148, v154);
    v155 = mult_arg1_arg2;
    v149 = integer_div_arg1_arg2;
    v146 = and_arg1_arg2;
    v138 = add_arg1_arg2(3879220815LL, 1303544047LL, 1673289997LL);
    v126 = or_arg1_arg2(119385303LL, 3231329148LL, 141954786LL);
    v121 = bitwise_not;
    v132 = and_arg1_arg2(1503872738LL, 978965565LL, 1470160614LL);
    v116 = mult_arg1_arg2(761654413LL, 3043887596LL, 4085454309LL);
    v113 = mult_arg1_arg2;
    v110 = xor_first_two(3333670936LL, 2147831941LL, 2217132274LL);
    v107 = add_arg1_arg2(4141055499LL, 1038626365LL, 1517838417LL);
    v104 = xor_first_two;
    v102 = add_arg1_arg2(2686461105LL, 3867813406LL, 686930351LL);
    v101 = xor_first_two(3259940977LL, 1820144441LL, 2738368048LL);
    v100 = mult_arg1_arg2;
    v13 = bitwise_not(2920661428LL, 408102610LL, 758347707LL);
    v14 = xor_first_two(2688446990LL, 3924691225LL, 3780184521LL);
    v15 = or_arg1_arg2;
    v16 = xor_first_two(715168552LL, 4203380807LL, 4042894304LL);
    v17 = and_arg1_arg2(3362982059LL, 1951226027LL, 2091265364LL);
    v18 = mult_arg1_arg2(2447727191LL, 4231433857LL, 2356928693LL);
    v19 = v15(v18, v17, v16);
    v20 = v100(v19, v14, v13);
    v21 = v104(v20, v101, v102);
    v22 = v113(v21, v107, v110);
    v23 = v121(v22, v116, v132);
    v24 = v146(v23, v126, v138);
    v25 = v149(v24, 7LL, 1501804614LL);
    v26 = v155(v25, 7LL, 3199106012LL);
    v27 = pow(2LL, (unsigned int)((_DWORD)v159 - v26 + 1), 3474473344LL);
    
    // end of static1
    
    
    v173 = v162(second, v27, 2318416522LL);
    
    // start of static2
    
    v163 = integer_div_arg1_arg2;               
    v28 = bitwise_not;
    LODWORD(v159) = or_arg1_arg2(4161192337LL, 897521730LL, 2969376499LL);
    LODWORD(v155) = or_arg1_arg2(2193193919LL, 1223334958LL, 3918650481LL);
    v29 = or_arg1_arg2;
    LODWORD(v149) = bitwise_not(1817983129LL, 994921689LL, 3011477667LL);
    LODWORD(v146) = bitwise_not(1066537828LL, 1283116571LL, 2740369546LL);
    v30 = and_arg1_arg2;
    v139 = mult_arg1_arg2(2890954343LL, 1376537582LL, 2181383581LL);
    v127 = and_arg1_arg2(1400330689LL, 1110986033LL, 4131805349LL);
    v122 = and_arg1_arg2;
    v31 = and_arg1_arg2(2171261435LL, 146029695LL, 3613482069LL);
    v32 = add_arg1_arg2(1785636003LL, 1488736597LL, 1361352486LL);
    v33 = mult_arg1_arg2(2535233854LL, 167541471LL, 1730975460LL);
    v34 = v122(v33, v32, v31);
    v35 = v30(v34, v127, v139);
    v36 = v29(v35, (unsigned int)v146, (unsigned int)v149);
    LODWORD(v30) = v28(v36, (unsigned int)v155, (unsigned int)v159);
    v160 = mult_arg1_arg2;
    v156 = integer_div_arg1_arg2;
    v150 = bitwise_not;
    LODWORD(v146) = or_arg1_arg2(4161192337LL, 897521730LL, 2969376499LL);
    v140 = or_arg1_arg2(2193193919LL, 1223334958LL, 3918650481LL);
    v128 = or_arg1_arg2;
    LODWORD(v122) = bitwise_not(1817983129LL, 994921689LL, 3011477667LL);
    v133 = bitwise_not(1066537828LL, 1283116571LL, 2740369546LL);
    v117 = and_arg1_arg2;
    LODWORD(v113) = mult_arg1_arg2(2890954343LL, 1376537582LL, 2181383581LL);
    LODWORD(v29) = and_arg1_arg2(1400330689LL, 1110986033LL, 4131805349LL);
    v37 = and_arg1_arg2;
    v38 = and_arg1_arg2(2171261435LL, 146029695LL, 3613482069LL);
    v39 = add_arg1_arg2(1785636003LL, 1488736597LL, 1361352486LL);
    v40 = mult_arg1_arg2(2535233854LL, 167541471LL, 1730975460LL);
    v41 = v37(v40, v39, v38);
    v42 = v117(v41, (unsigned int)v29, (unsigned int)v113);
    v43 = v128(v42, v133, (unsigned int)v122);
    v44 = v150(v43, v140, (unsigned int)v146);
    v45 = v156(v44, 7LL, 314984731LL);
    v46 = v160(v45, 7LL, 3158207403LL);
    v47 = pow(2LL, (unsigned int)((_DWORD)v30 - v46 + 1), 1008871084LL);
    
    // end of static2
    
    v174 = v163(second, v47, 197348412LL);
    v175 = read_integer_at_offset(S, v172, 447433706LL);
    v175 = add_arg1_arg2(v175, v168, 324602339LL);
    v176 = xor_first_two(v173, v174, 3329644733LL);
    v176 = add_arg1_arg2(v176, second, 1639485244LL);
    v48 = (void (__fastcall *)(unsigned int *, _QWORD, __int64))add_at_arg1_arg2;
    v49 = or_arg1_arg2;
    v50 = and_arg1_arg2;
    v51 = bitwise_not(v175, 653621050LL, 1423983245LL);
    LODWORD(v29) = v50(v51, v176, 1027126639LL);
    v52 = and_arg1_arg2;
    v53 = bitwise_not(v176, 3065730485LL, 1912144072LL);
    v54 = v52(v53, v175, 947070206LL);
    v55 = v49(v54, (unsigned int)v29, 1647839532LL);
    v48(&first, v55, 3300199018LL);
    
    // start of static3
    
    v164 = integer_div_arg1_arg2;               
    v56 = and_arg1_arg2;
    LODWORD(v160) = or_arg1_arg2(861961045LL, 3729566995LL, 1481462251LL);
    LODWORD(v156) = or_arg1_arg2(1015811113LL, 2892287594LL, 442448913LL);
    v151 = and_arg1_arg2;
    LODWORD(v146) = bitwise_not(2196330534LL, 253421437LL, 4099738111LL);
    v141 = bitwise_not(4269575248LL, 3279378526LL, 2915436928LL);
    v129 = mult_arg1_arg2;
    LODWORD(v122) = mult_arg1_arg2(3945310850LL, 2125372249LL, 640191863LL);
    v134 = xor_first_two(3731616660LL, 226513103LL, 2241794849LL);
    v118 = add_arg1_arg2;
    LODWORD(v113) = or_arg1_arg2(2297915302LL, 1861862940LL, 3719301326LL);
    LODWORD(v29) = xor_first_two(2214532763LL, 4266447871LL, 2078477805LL);
    v57 = add_arg1_arg2;
    LODWORD(v49) = xor_first_two(4257972909LL, 961609286LL, 557951297LL);
    LODWORD(v48) = add_arg1_arg2(4276531665LL, 513176722LL, 2816369635LL);
    v58 = add_arg1_arg2(2694453255LL, 2773612332LL, 2055293076LL);
    v59 = v57(v58, (unsigned int)v48, (unsigned int)v49);
    v60 = v118(v59, (unsigned int)v29, (unsigned int)v113);
    v61 = v129(v60, v134, (unsigned int)v122);
    v62 = v151(v61, v141, (unsigned int)v146);
    LODWORD(v160) = v56(v62, (unsigned int)v156, (unsigned int)v160);
    v157 = mult_arg1_arg2;
    v152 = integer_div_arg1_arg2;
    v147 = and_arg1_arg2;
    v142 = or_arg1_arg2(861961045LL, 3729566995LL, 1481462251LL);
    LODWORD(v129) = or_arg1_arg2(1015811113LL, 2892287594LL, 442448913LL);
    v123 = and_arg1_arg2;
    v135 = bitwise_not(2196330534LL, 253421437LL, 4099738111LL);
    LODWORD(v118) = bitwise_not(4269575248LL, 3279378526LL, 2915436928LL);
    v114 = mult_arg1_arg2;
    v111 = mult_arg1_arg2(3945310850LL, 2125372249LL, 640191863LL);
    v108 = xor_first_two(3731616660LL, 226513103LL, 2241794849LL);
    v105 = add_arg1_arg2;
    LODWORD(v56) = or_arg1_arg2(2297915302LL, 1861862940LL, 3719301326LL);
    LODWORD(v29) = xor_first_two(2214532763LL, 4266447871LL, 2078477805LL);
    v63 = add_arg1_arg2;
    LODWORD(v49) = xor_first_two(4257972909LL, 961609286LL, 557951297LL);
    LODWORD(v48) = add_arg1_arg2(4276531665LL, 513176722LL, 2816369635LL);
    v64 = add_arg1_arg2(2694453255LL, 2773612332LL, 2055293076LL);
    v65 = v63(v64, (unsigned int)v48, (unsigned int)v49);
    v66 = v105(v65, (unsigned int)v29, (unsigned int)v56);
    v67 = v114(v66, v108, v111);
    v68 = v123(v67, (unsigned int)v118, v135);
    v69 = v147(v68, (unsigned int)v129, v142);
    v70 = v152(v69, 7LL, 3278750119LL);
    v71 = v157(v70, 7LL, 2227083366LL);
    v72 = pow(2LL, (unsigned int)((_DWORD)v160 - v71 + 1), 336464741LL);
    
    // end of static3
    
    v177 = v164(first, v72, 2481324780LL);
    
    // start of static4
    
    v165 = mult_arg1_arg2;                      
    v73 = bitwise_not;
    LODWORD(v160) = mult_arg1_arg2(748454888LL, 2385136313LL, 1546242347LL);
    LODWORD(v157) = mult_arg1_arg2(840257265LL, 914175242LL, 4105844533LL);
    v74 = add_arg1_arg2;
    LODWORD(v152) = or_arg1_arg2(4105116680LL, 428215568LL, 3893947801LL);
    LODWORD(v147) = add_arg1_arg2(1050111887LL, 1686078548LL, 3318984746LL);
    v75 = mult_arg1_arg2;
    v143 = add_arg1_arg2(3758740715LL, 2625692561LL, 2391327272LL);
    LODWORD(v129) = add_arg1_arg2(3866433077LL, 39691962LL, 1819467951LL);
    v124 = or_arg1_arg2;
    LODWORD(v49) = mult_arg1_arg2(2001992146LL, 1101967082LL, 2965024266LL);
    LODWORD(v48) = xor_first_two(3387452349LL, 2334297832LL, 3975767251LL);
    v76 = and_arg1_arg2(2824204296LL, 3303156400LL, 1728631218LL);
    v77 = v124(v76, (unsigned int)v48, (unsigned int)v49);
    v78 = v75(v77, (unsigned int)v129, v143);
    v79 = v74(v78, (unsigned int)v147, (unsigned int)v152);
    LODWORD(v75) = v73(v79, (unsigned int)v157, (unsigned int)v160);
    v161 = mult_arg1_arg2;
    v158 = integer_div_arg1_arg2;
    v153 = bitwise_not;
    LODWORD(v147) = mult_arg1_arg2(748454888LL, 2385136313LL, 1546242347LL);
    v144 = mult_arg1_arg2(840257265LL, 914175242LL, 4105844533LL);
    v130 = add_arg1_arg2;
    LODWORD(v124) = or_arg1_arg2(4105116680LL, 428215568LL, 3893947801LL);
    v136 = add_arg1_arg2(1050111887LL, 1686078548LL, 3318984746LL);
    v119 = mult_arg1_arg2;
    LODWORD(v114) = add_arg1_arg2(3758740715LL, 2625692561LL, 2391327272LL);
    LODWORD(v74) = add_arg1_arg2(3866433077LL, 39691962LL, 1819467951LL);
    v80 = or_arg1_arg2;
    LODWORD(v49) = mult_arg1_arg2(2001992146LL, 1101967082LL, 2965024266LL);
    LODWORD(v48) = xor_first_two(3387452349LL, 2334297832LL, 3975767251LL);
    v81 = and_arg1_arg2(2824204296LL, 3303156400LL, 1728631218LL);
    v82 = v80(v81, (unsigned int)v48, (unsigned int)v49);
    v83 = v119(v82, (unsigned int)v74, (unsigned int)v114);
    v84 = v130(v83, v136, (unsigned int)v124);
    v85 = v153(v84, v144, (unsigned int)v147);
    v86 = v158(v85, 7LL, 3123289780LL);
    v87 = v161(v86, 7LL, 3107866936LL);
    v88 = pow(2LL, (unsigned int)((_DWORD)v75 - v87 + 1), 678071872LL);
    
    // end of static4
    
    
    v178 = v165(first, v88, 2809463385LL);
    v89 = or_arg1_arg2;
    v90 = and_arg1_arg2;
    v91 = bitwise_not(v177, 4059826110LL, 1422414646LL);
    LODWORD(v80) = v90(v91, v178, 3879744432LL);
    v92 = and_arg1_arg2;
    v93 = bitwise_not(v178, 4049347960LL, 1935114105LL);
    v94 = v92(v93, v177, 3415169072LL);
    v179 = v89(v94, (unsigned int)v80, 4120885783LL);
    add_at_arg1_arg2(&v168, 3284565212LL, 2416574660LL);
    v180 = add_arg1_arg2(v179, first, 1817052189LL);
    v95 = and_arg1_arg2;
    v96 = integer_div_arg1_arg2(v168, 2048LL, 2226869969LL);
    v181 = v95(255LL, v96, 472317835LL);
    v182 = read_integer_at_offset(S, v181, 1977943222LL);
    v183 = add_arg1_arg2(v182, v168, 4263146526LL);
    v97 = (void (__fastcall *)(unsigned int *, _QWORD, __int64))add_at_arg1_arg2;
    v98 = xor_first_two(v180, v183, 2191071771LL);
    v97(&second, v98, 1183580100LL);
    v185 += 1uLL;
  }
  while ( 0x478 >= v185 );
  *input = first;
  input[1] = second;
  return v187 - __readfsqword(0x28u);
}
```

this function seems scary, but we will go at it bit by bit till we understand it.

at first, it takes our 8 bytes buf and splits it into two unsigned ints, first and second, then it sets S a State array (similar to rc4) using the key, this array is never written to, then it loops 0x478 times while doing some operations on first and second, in the end it writes first and second back to input. 

now before i started reversing this function, i noticed that there are four regions of code that only use constant values, i marked them on the code above, here is an example one:

```c
v162 = mult_arg1_arg2;                      
    v159 = and_arg1_arg2;
    v154 = add_arg1_arg2(3879220815LL, 1303544047LL, 1673289997LL);
    v148 = or_arg1_arg2(119385303LL, 3231329148LL, 141954786LL);
    v145 = bitwise_not;
    v137 = and_arg1_arg2(1503872738LL, 978965565LL, 1470160614LL);
    v125 = mult_arg1_arg2(761654413LL, 3043887596LL, 4085454309LL);
    v120 = mult_arg1_arg2;
    v131 = xor_first_two(3333670936LL, 2147831941LL, 2217132274LL);
    v115 = add_arg1_arg2(4141055499LL, 1038626365LL, 1517838417LL);
    v112 = xor_first_two;
    v109 = add_arg1_arg2(2686461105LL, 3867813406LL, 686930351LL);
    v106 = xor_first_two(3259940977LL, 1820144441LL, 2738368048LL);
    v103 = mult_arg1_arg2;
    v2 = bitwise_not(2920661428LL, 408102610LL, 758347707LL);
    v3 = xor_first_two(2688446990LL, 3924691225LL, 3780184521LL);
    v4 = or_arg1_arg2;
    v5 = xor_first_two(715168552LL, 4203380807LL, 4042894304LL);
    v6 = and_arg1_arg2(3362982059LL, 1951226027LL, 2091265364LL);
    v7 = mult_arg1_arg2(2447727191LL, 4231433857LL, 2356928693LL);
    v8 = v4(v7, v6, v5);
    v9 = v103(v8, v3, v2);
    v10 = v112(v9, v106, v109);
    v11 = v120(v10, v115, v131);
    v12 = v145(v11, v125, v137);
    LODWORD(v159) = v159(v12, v148, v154);
    v155 = mult_arg1_arg2;
    v149 = integer_div_arg1_arg2;
    v146 = and_arg1_arg2;
    v138 = add_arg1_arg2(3879220815LL, 1303544047LL, 1673289997LL);
    v126 = or_arg1_arg2(119385303LL, 3231329148LL, 141954786LL);
    v121 = bitwise_not;
    v132 = and_arg1_arg2(1503872738LL, 978965565LL, 1470160614LL);
    v116 = mult_arg1_arg2(761654413LL, 3043887596LL, 4085454309LL);
    v113 = mult_arg1_arg2;
    v110 = xor_first_two(3333670936LL, 2147831941LL, 2217132274LL);
    v107 = add_arg1_arg2(4141055499LL, 1038626365LL, 1517838417LL);
    v104 = xor_first_two;
    v102 = add_arg1_arg2(2686461105LL, 3867813406LL, 686930351LL);
    v101 = xor_first_two(3259940977LL, 1820144441LL, 2738368048LL);
    v100 = mult_arg1_arg2;
    v13 = bitwise_not(2920661428LL, 408102610LL, 758347707LL);
    v14 = xor_first_two(2688446990LL, 3924691225LL, 3780184521LL);
    v15 = or_arg1_arg2;
    v16 = xor_first_two(715168552LL, 4203380807LL, 4042894304LL);
    v17 = and_arg1_arg2(3362982059LL, 1951226027LL, 2091265364LL);
    v18 = mult_arg1_arg2(2447727191LL, 4231433857LL, 2356928693LL);
    v19 = v15(v18, v17, v16);
    v20 = v100(v19, v14, v13);
    v21 = v104(v20, v101, v102);
    v22 = v113(v21, v107, v110);
    v23 = v121(v22, v116, v132);
    v24 = v146(v23, v126, v138);
    v25 = v149(v24, 7LL, 1501804614LL);
    v26 = v155(v25, 7LL, 3199106012LL);
    v27 = pow(2LL, (unsigned int)((_DWORD)v159 - v26 + 1), 3474473344LL);
```

it basically does some operations then calls pow(2, result) (third arg of pow is not used), then the rest of the logic uses it’s result for calculations, this pattern repeats four times inside the loop, we can replace those regions by their final results in the decompilation to simplify it.

to get this four constants i used gdb with dprintf (with the final instruction before pow returns) to print the return value of pow.

```c
dprintf *0x162E+0x555555554000, "rax = 0x%02x\n", $rax
```

we get these values

```c
rax = 0x08
rax = 0x08
rax = 0x20
rax = 0x10
rax = 0x08
rax = 0x08
rax = 0x20
rax = 0x10
```

and sure enough, these four values kept repeating, meaning my observation was right, now putting them inside the loop gives us the following:

```c
do
  {
    v172 = v168 & 3LL;
    v27 = 0x8; // static 1 output
    v173 = second * v27
    v47 = 0x8; // static 2 output
    v174 = second / v47;
    v175 = S[v172];
    v175 = v175+v168;
    v176 = v173^v174;
    v176 = v176+second;
    v51 = ~v175;
    v29 = v51 & v176;
    v53 = ~v176;
    v54 = v53 & v175;
    v55 = v54 | v29;
    first += v55;
    
    v72 =0x20; // static 3 output
    v177 = first / v72;
    v88 = 0x10; // static 4 output
    v178 = first * v88;
    v91 = ~v177;
    v80 = v91 & v178;
    v93 = ~v178;
    v94 = v93 & v177;
    v179 = v94 | v80;
    v168 +=  3284565212;
    v180 = v179 + first;
    v96 = v168 / 0x800LL;
    v181 = 255LL & v96;
    v182 = S[v181]
    v183 = v182 + v168;
    v98 = v180 ^ v183;
    second += v98;
    v185 += 1uLL;
  }
  while ( 0x478 >= v185 );
```

now as you can see, this is pretty good, but i still used llm to turn it into a more simplified c version, so i can use it for scripting:

```c
uint64_t enc(uint32_t *input, uint32_t *key) {
    uint32_t S[256];
    uint32_t first = input[0];
    uint32_t second = input[1];
    uint32_t v168 = 0;
    uint64_t v185 = 0;

    // Initialize S-box
    for (int i = 0; i <= 255; ++i)
        S[i] = i;

    // RC4-style key scheduling
    uint32_t v170 = 0, v171 = 0;
    for (int i = 0; i <= 255; ++i) {
        uint32_t v184 = S[i];
        v170 = (v184 + v170 + key[v171]) & 0xFF;
        uint32_t tmp = S[i];
        S[i] = S[v170];
        S[v170] = tmp;

        if (++v171 > 3)
            v171 = 0;
    }

    do {
        uint32_t v172 = v168 & 3;
        uint32_t v175 = (S[v172] + v168);
        uint32_t v176 = ((second << 3) ^ (second >> 3)) + second;
        first += v175 ^ v176;  // Simplified from multiple bitwise operations

        // Second part operations
        uint32_t v179 = (first >> 5) ^ (first << 4);
        v168 += 0x9D175C01U;  // Constant increment
        uint32_t v180 = v179 + first;

        // Final operations
        uint32_t v181 = (v168 >> 11) & 0xFF;
        uint32_t v183 = S[v181] + v168;
        second += v180 ^ v183;

        v185 += 1;
    } while (v185 <= 0x478);

    input[0] = first;
    input[1] = second;

}
```

the four static constants are used for multiplication and division, and since they are powers of 2, they are simplified to right and left shifts. it is also using v168 to index into the state array, it is incrementing it by a constant value (0x9D175C01).

now our task is to reverse this function:

- we start with the cipher text at the end of the loop of the encryption, we have the last value of v168, which is always incremented by 0x9D175C01
- v181 = (v168 >> 11) & 0xFF;    we have this since we have the value v168
- v183 = S[v181] + v168;    we also have this since we have v181 and v168
- v179 = (first >> 5) ^ (first << 4);       we know this value although it uses first, because it uses it after incrementing it, ie: it uses the encrypted value of first that we have
- v180 = v179 + first;   same for this, and now we can decrypt the second value by subtracting v180^v183
- and we decrypt “first” too since it uses the decrypted “second” in it’s encryption, which we have.

here is the final decryption script:

```c
uint64_t dec(uint32_t first, uint32_t second, uint32_t *key, uint32_t* output) {
    uint32_t S[256];
    uint32_t v168 = 0;
    uint64_t v185 = 0;

    // Initialize S-box
    for (int i = 0; i <= 255; ++i)
        S[i] = i;

    // RC4-style key scheduling
    uint32_t v170 = 0, v171 = 0;
    for (int i = 0; i <= 255; ++i) {
        uint32_t v184 = S[i];
        v170 = (v184 + v170 + key[v171]) & 0xFF;
        uint32_t tmp = S[i];
        S[i] = S[v170];
        S[v170] = tmp;

        if (++v171 > 3)
            v171 = 0;
    }

    v168 = 0xa2c473fc; // this is the last value of v168

    do {
        uint32_t v181 = (v168 >> 11) & 0xFF;
        uint32_t v183 = S[v181] + v168;

        uint32_t v179 = (first >> 5) ^ (first << 4);

        uint32_t v180 = v179 + first;

        second -= v180 ^ v183;

        v168-=0x9D175C01; // we are going backwards now

        uint32_t v172 = v168 & 3; // this we have, just decrement v168 
        uint32_t v175 = (S[v172] + v168); // this too we have
                                          
        uint32_t v176 = ((second << 3) ^ (second >> 3)) + second; // use the decrypted second value to get this value
                                          
        first -= v175 ^ v176;  // xor this to get the decrypted  first value
        v185+=1;

    }
    while (v185 <= 0x478);
    

    printf("first = 0x%x , second = 0x%x\n", first, second);

    output[0] = first;
    output[1]=second;
    

}
```

using it on the cipher 0xF06203EC3D2C5B74 for the level1 with the key extracted using gdb we get

![Screenshot from 2025-07-07 20-13-17.png](rev%20r3loads%20from%20r3ctf%202025%20writeup%202297bde5e8e280c88485ebc2b9bb9edd/Screenshot_from_2025-07-07_20-13-17.png)

it worked!!

## the “auto” part:

to start scripting decryption for the 11423 executables we first need to know what changes between them, opening the second executable and reversing it (just like in the “rev” part) i noticed that four things change:

- the key (v91)
- the constant that increments v168 is different
- the four static values that are calculated inside the loop and used for shifting
- and obviously the cipher text

to get the right input for any executable we have to extract these values, but first i updated my decrypt function so it uses dynamic keys, constant and shifts like this:

```c
uint64_t dec(uint32_t first, uint32_t second, uint32_t *key, uint32_t c, uint32_t* shifts) {
    uint32_t S[256];
    uint32_t v168 = 0;
    uint64_t v185 = 0;

    // Initialize S-box
    for (int i = 0; i <= 255; ++i)
        S[i] = i;

    // RC4-style key scheduling
    uint32_t v170 = 0, v171 = 0;
    for (int i = 0; i <= 255; ++i) {
        uint32_t v184 = S[i];
        v170 = (v184 + v170 + key[v171]) & 0xFF;
        uint32_t tmp = S[i];
        S[i] = S[v170];
        S[v170] = tmp;

        if (++v171 > 3)
            v171 = 0;
    }
    uint32_t finalc = 0;
    for (int i = 0; i <= 0x478; i++) {
        finalc += c;
    }
    v168 = finalc;

    do {
        uint32_t v181 = (v168 >> 11) & 0xFF; // 3ndna
        uint32_t v183 = S[v181] + v168; // 3ndna

        uint32_t v179 = (first >> shifts[2]) ^ (first << shifts[3]);

        uint32_t v180 = v179 + first;

        second -= v180 ^ v183;

        v168-=c;

        uint32_t v172 = v168 & 3; // this we have, just decrement v168 
        uint32_t v175 = (S[v172] + v168); // this too we have
                                          
        uint32_t v176 = ((second << shifts[0]) ^ (second >> shifts[1])) + second; // use the decrypted second value to get this value
                                          
        first -= v175 ^ v176;  // xor this to get the decrypted  first value
        v185+=1;

    }
    while (v185 <= 0x478);
    
    uint64_t rslt = first | ((uint64_t)second << 32);
    return rslt ;

}
// c is the increment of v168
uint64_t decrypt(uint64_t cipher, uint32_t* key, uint32_t c, uint32_t* shifts) {
    
    uint32_t first = cipher & 0xffffffff;
    uint32_t second = cipher >> 32;
    
    return dec(first, second, key, c, shifts);
}
```

### Extracting the values from the executble:

to extract the values dynamicly i used libdebug, since it is waaay faster than gdbscripting (gdb scripting would took hours).

we start by extracting the key, to do that i set a breakpoint at read then return from read and go four instructions after it, to reach the call for the encrypt function

![Screenshot from 2025-07-07 21-16-33.png](rev%20r3loads%20from%20r3ctf%202025%20writeup%202297bde5e8e280c88485ebc2b9bb9edd/Screenshot_from_2025-07-07_21-16-33.png)

after that i read 4*sizeof(unsigned int) bytes of memory starting at rsi to get the key.

```python
from libdebug import debugger
d = debugger("./beatme")

pipe= d.run()
pipe.send(b'a'*8) # send dummy data so it does not get stuck at read
d.breakpoint('read')

d.cont() # now we are the start of read
d.finish() # return for the read function
for _ in range(4):
		d.step()
# now we are at "call encrypt"
rsi  = d.regs.rsi
data = d.memory[rsi:rsi+0x10]
key  = [int.from_bytes(data[i:i+4], 'little') for i in range(0, 0x10, 4)] 
```

to extract the cipher from the binary, i noticed that the instructions that do the loading and  comparision are always the same

![Screenshot from 2025-07-07 21-37-48.png](rev%20r3loads%20from%20r3ctf%202025%20writeup%202297bde5e8e280c88485ebc2b9bb9edd/Screenshot_from_2025-07-07_21-37-48.png)

bytes 8b45a83d are the mov instruction and the first byte of cmp instruction, i use these to find their offset in the binary then add 4 and read a dword.

```python
with open(f"./beatme", 'rb') as f:
        filedata = f.read()
a = filedata.find(b'\x8b\x45\xa8\x3d')+4 # mov    eax,DWORD PTR [rbp-0x58] ; cmp
b = filedata.find(b'\x8b\x45\xac\x3d')+4 # mov    eax,DWORD PTR [rbp-0x54] ; cmp

cipher = int.from_bytes(filedata[a:a+4], 'little') | (int.from_bytes(filedata[b:b+4], 'little') << 32)
```

now we need to extract the shift values, to do that i decided to set a breakpoint at the end of the pow function and print the value at rax (return value).

![Screenshot from 2025-07-07 22-04-49.png](rev%20r3loads%20from%20r3ctf%202025%20writeup%202297bde5e8e280c88485ebc2b9bb9edd/Screenshot_from_2025-07-07_22-04-49.png)

breakpoint is set at 0x162f.

i knew by observation the the pow function was the same in all executables, and since we can’t hard code the address of pow cause it changes, i decided to search for the offset of pow by it’s first bytes, and we add the size of it, to reach it’s last instruction.

```python
powstart = b'\xf3\x0f\x1e\xfaUH\x89\xe5\x89}\xec\x89u\xe8\x89U\xe4\x83}\xe8\x00'
addr = filedata.find(powstart)+0x3e # addr points to ret instruction of pow
```

now we use this to set a breakpoint and print the values at eax

```python
# after the code that extracts the key
d.breakpoint(addr, file='binary')

shifts = []
for _ in range(4):
		d.cont()
    shifts.append(math.log2(d.regs.rax))
    # we use math.log2 since divising by 0x8
    # is the same as shifting to right by 3 (log2(8) == 3)
```

now to get the v168 increment constant c, we know from ida that v168 is stored at rbp-0x494, now each loop calls pow 4 times, so in the fifth call of pow (which we are setting a breapoint at), we would be in the second loop, v168 would be incremented one time, it would be equal to the increment constant, so we just get the value at v168.

```python
# after the shifts extraction
d.cont()
rbp = d.regs.rbp
c = int.from_bytes(d.memory[rbp-0x494:rbp-0x494+4], 'little')
```

and that’s it!

after this we store all the keys/ciphers/shifts and c’s in a files. and we use that file in the decryption in c, i did this because my decryption was in c.

here are the final extract[.py](http://test.py) and decrypt.c scripts.

after running them we get this jpg

![output.jpg](rev%20r3loads%20from%20r3ctf%202025%20writeup%202297bde5e8e280c88485ebc2b9bb9edd/output.jpg)